

package com.segundo.pro;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author ldric
 */

@SpringBootApplication
@Controller
//@RestController
@Slf4j
public class ControladorInicio {
    @GetMapping("/")
    public String inicio(){
         log.info("Ejecutando el controlador de inicio");
        return "index";
    }
}
